package com.customboard.ime

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class KeyboardLayoutView(
    context: Context,
    private val prefs: KeyboardPreferences,
    private val listener: Listener
) : LinearLayout(context) {

    interface Listener {
        fun onTextInput(text: String)
        fun onBackspace()
        fun onEnter()
        fun onCursorMove(delta: Int)
        fun onMacroAction(action: String)
        fun onKeyPressFeedback(isSpecial: Boolean)
    }

    private var isRussian = true
    private var isSymbols = false
    private var isShifted = false
    private var spaceStartX = 0f

    private val ruRows = listOf(
        listOf("й", "ц", "у", "к", "е", "н", "г", "ш", "щ", "з", "х"),
        listOf("ф", "ы", "в", "а", "п", "р", "о", "л", "д", "ж", "э"),
        listOf("SHIFT", "я", "ч", "с", "м", "и", "т", "ь", "б", "ю", "DEL")
    )

    private val enRows = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("SHIFT", "z", "x", "c", "v", "b", "n", "m", "DEL")
    )

    private val symRows = listOf(
        listOf("!", "@", "#", "$", "%", "^", "&", "*", "(", ")"),
        listOf("-", "_", "=", "+", "[", "]", "{", "}", ";", ":"),
        listOf("SHIFT", "'", """, "/", "?", "\\", "|", "<", ">", "DEL")
    )

    init {
        orientation = VERTICAL
        rebuildKeyboard()
    }

    fun rebuildKeyboard() {
        removeAllViews()
        val theme = prefs.getActiveTheme()
        setBackgroundColor(theme.boardBg)
        val pad = dp(6)
        setPadding(pad, dp(8), pad, dp(12))

        // 1. Custom Top Macro Bar
        if (prefs.showCustomMacroRow) {
            val macroRow = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)).apply {
                    bottomMargin = dp(4)
                }
            }
            val macros = prefs.customMacrosCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            for (macro in macros) {
                val btn = createKeyView(macro, isSpecial = true, isAccent = false, heightDp = 34)
                btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                btn.setOnClickListener {
                    listener.onKeyPressFeedback(true)
                    listener.onMacroAction(macro)
                }
                macroRow.addView(btn, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginStart = dp(3)
                    marginEnd = dp(3)
                })
            }
            addView(macroRow)
        }

        // 2. Number Row
        if (prefs.showNumberRow) {
            val numRow = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(prefs.keyHeightDp - 6)).apply {
                    bottomMargin = dp(4)
                }
            }
            listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0").forEach { num ->
                val btn = createKeyView(num, isSpecial = false, isAccent = false)
                btn.setOnClickListener {
                    listener.onKeyPressFeedback(false)
                    listener.onTextInput(num)
                }
                numRow.addView(btn, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                })
            }
            addView(numRow)
        }

        // 3. Main Alpha/Symbol Rows
        val activeRows = when {
            isSymbols -> symRows
            isRussian -> ruRows
            else -> enRows
        }

        for (rowKeys in activeRows) {
            val rowLayout = LinearLayout(context).apply {
                orientation = HORIZONTAL
                layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(prefs.keyHeightDp)).apply {
                    bottomMargin = dp(5)
                }
            }

            for (keyLabel in rowKeys) {
                val isSpec = keyLabel == "SHIFT" || keyLabel == "DEL"
                val display = when (keyLabel) {
                    "SHIFT" -> if (isShifted) "⬆" else "⇧"
                    "DEL" -> "⌫"
                    else -> if (isShifted) keyLabel.uppercase() else keyLabel
                }
                val weight = if (isSpec) 1.4f else 1.0f
                val keyView = createKeyView(display, isSpecial = isSpec, isAccent = (keyLabel == "SHIFT" && isShifted))

                keyView.setOnClickListener {
                    listener.onKeyPressFeedback(isSpec)
                    when (keyLabel) {
                        "SHIFT" -> {
                            isShifted = !isShifted
                            rebuildKeyboard()
                        }
                        "DEL" -> listener.onBackspace()
                        else -> {
                            listener.onTextInput(display)
                            if (isShifted) {
                                isShifted = false
                                rebuildKeyboard()
                            }
                        }
                    }
                }
                rowLayout.addView(keyView, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                })
            }
            addView(rowLayout)
        }

        // 4. Bottom Row (?123, Globe, Comma, Spacebar with Cursor Trackpad, Period, Enter)
        val bottomRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(prefs.keyHeightDp))
        }

        val symBtn = createKeyView(if (isSymbols) "АБВ" else "?123", isSpecial = true, isAccent = false)
        symBtn.setOnClickListener {
            listener.onKeyPressFeedback(true)
            isSymbols = !isSymbols
            rebuildKeyboard()
        }
        bottomRow.addView(symBtn, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.3f).apply { marginEnd = dp(3) })

        val langBtn = createKeyView("🌐", isSpecial = true, isAccent = false)
        langBtn.setOnClickListener {
            listener.onKeyPressFeedback(true)
            isSymbols = false
            isRussian = !isRussian
            rebuildKeyboard()
        }
        bottomRow.addView(langBtn, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.0f).apply { marginEnd = dp(3) })

        val commaBtn = createKeyView(",", isSpecial = false, isAccent = false)
        commaBtn.setOnClickListener {
            listener.onKeyPressFeedback(false)
            listener.onTextInput(",")
        }
        bottomRow.addView(commaBtn, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.9f).apply { marginEnd = dp(3) })

        // Spacebar with Gboard-style swipe cursor control
        val spaceLabel = if (isRussian) "Русский • CustomBoard" else "English • CustomBoard"
        val spaceBtn = createKeyView(spaceLabel, isSpecial = false, isAccent = false)
        spaceBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        @SuppressLint("ClickableViewAccessibility")
        spaceBtn.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    spaceStartX = event.rawX
                    listener.onKeyPressFeedback(true)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - spaceStartX
                    if (abs(dx) > dp(18)) {
                        val step = if (dx > 0) 1 else -1
                        listener.onCursorMove(step)
                        spaceStartX = event.rawX
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(event.rawX - spaceStartX) < dp(12)) {
                        listener.onTextInput(" ")
                    }
                    true
                }
                else -> false
            }
        }
        bottomRow.addView(spaceBtn, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 4.2f).apply { marginEnd = dp(3) })

        val dotBtn = createKeyView(".", isSpecial = false, isAccent = false)
        dotBtn.setOnClickListener {
            listener.onKeyPressFeedback(false)
            listener.onTextInput(".")
        }
        bottomRow.addView(dotBtn, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.9f).apply { marginEnd = dp(3) })

        val enterBtn = createKeyView("↵", isSpecial = true, isAccent = true)
        enterBtn.setOnClickListener {
            listener.onKeyPressFeedback(true)
            listener.onEnter()
        }
        bottomRow.addView(enterBtn, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.4f))

        addView(bottomRow)
    }

    private fun createKeyView(label: String, isSpecial: Boolean, isAccent: Boolean, heightDp: Int = prefs.keyHeightDp): TextView {
        val theme = prefs.getActiveTheme()
        val bgDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(prefs.keyCornerRadiusDp).toFloat()
            val fill = when {
                isAccent -> theme.accentBg
                isSpecial -> theme.specialKeyBg
                else -> theme.keyBg
            }
            setColor(fill)
            if (prefs.keyBorderStrokeDp > 0) {
                setStroke(dp(prefs.keyBorderStrokeDp), theme.borderColor)
            }
        }

        return TextView(context).apply {
            text = label
            gravity = Gravity.CENTER
            background = bgDrawable
            setTextColor(if (isAccent) Color.parseColor("#111115") else theme.keyText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (isSpecial) 15f else 18f)
            isAllCaps = false
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
