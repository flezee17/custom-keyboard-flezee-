package com.customboard.ime

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class CustomBoardIME : InputMethodService(), KeyboardLayoutView.Listener {

    private lateinit var prefs: KeyboardPreferences
    private lateinit var soundEngine: SoundEngine
    private var keyboardView: KeyboardLayoutView? = null

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPreferences(this)
        soundEngine = SoundEngine(this)
    }

    override fun onCreateInputView(): View {
        keyboardView = KeyboardLayoutView(this, prefs, this)
        return keyboardView!!
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        keyboardView?.rebuildKeyboard()
    }

    override fun onTextInput(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (selected.isNullOrEmpty()) {
            ic.deleteSurroundingText(1, 0)
        } else {
            ic.commitText("", 1)
        }
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
    }

    override fun onCursorMove(delta: Int) {
        val ic = currentInputConnection ?: return
        val keyCode = if (delta > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    override fun onMacroAction(action: String) {
        val ic = currentInputConnection ?: return
        when (action.lowercase()) {
            "copy" -> ic.performContextMenuAction(android.R.id.copy)
            "paste" -> ic.performContextMenuAction(android.R.id.paste)
            "cut" -> ic.performContextMenuAction(android.R.id.cut)
            "selectall" -> ic.performContextMenuAction(android.R.id.selectAll)
            "◀" -> onCursorMove(-1)
            "▶" -> onCursorMove(1)
            else -> ic.commitText(action, 1)
        }
    }

    override fun onKeyPressFeedback(isSpecial: Boolean) {
        soundEngine.playKeySound(prefs.soundProfile, prefs.soundVolume, isSpecial)
        val vibMs = prefs.vibrationMs
        if (vibMs > 0) {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(vibMs.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(vibMs.toLong())
            }
        }
    }

    override fun onDestroy() {
        soundEngine.release()
        super.onDestroy()
    }
}
