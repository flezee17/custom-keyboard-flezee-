package com.customboard.ime

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import kotlin.random.Random

class SoundEngine(context: Context) {
    private val soundPool: SoundPool
    private val soundMap = mutableMapOf<String, Int>()

    init {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(8)
            .setAudioAttributes(attrs)
            .build()

        soundMap["thock"] = soundPool.load(context, R.raw.sound_thock, 1)
        soundMap["blue"] = soundPool.load(context, R.raw.sound_blue, 1)
        soundMap["red"] = soundPool.load(context, R.raw.sound_red, 1)
        soundMap["bubble"] = soundPool.load(context, R.raw.sound_bubble, 1)
        soundMap["typewriter"] = soundPool.load(context, R.raw.sound_typewriter, 1)
    }

    fun playKeySound(profile: String, volumePercent: Int, isSpaceOrEnter: Boolean = false) {
        if (profile == "none" || volumePercent <= 0) return
        val soundId = soundMap[profile] ?: soundMap["thock"] ?: return
        val vol = (volumePercent / 100f).coerceIn(0f, 1f)
        // Slight pitch variation makes typing sound like real physical switches
        val baseRate = if (isSpaceOrEnter) 0.88f else 1.0f
        val rate = (baseRate + Random.nextFloat() * 0.08f - 0.04f).coerceIn(0.5f, 2.0f)
        soundPool.play(soundId, vol, vol, 1, 0, rate)
    }

    fun release() {
        soundPool.release()
    }
}
