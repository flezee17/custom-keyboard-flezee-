package com.customboard.ime

import android.content.Context
import android.graphics.Color

data class ThemeColors(
    val name: String,
    val boardBg: Int,
    val keyBg: Int,
    val specialKeyBg: Int,
    val accentBg: Int,
    val keyText: Int,
    val borderColor: Int
)

class KeyboardPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("customboard_prefs", Context.MODE_PRIVATE)

    var themePreset: String
        get() = prefs.getString("theme_preset", "gboard_dark") ?: "gboard_dark"
        set(value) = prefs.edit().putString("theme_preset", value).apply()

    var soundProfile: String
        get() = prefs.getString("sound_profile", "thock") ?: "thock"
        set(value) = prefs.edit().putString("sound_profile", value).apply()

    var soundVolume: Int
        get() = prefs.getInt("sound_volume", 85)
        set(value) = prefs.edit().putInt("sound_volume", value).apply()

    var vibrationMs: Int
        get() = prefs.getInt("vibration_ms", 18)
        set(value) = prefs.edit().putInt("vibration_ms", value).apply()

    var keyCornerRadiusDp: Int
        get() = prefs.getInt("key_radius_dp", 10)
        set(value) = prefs.edit().putInt("key_radius_dp", value).apply()

    var keyHeightDp: Int
        get() = prefs.getInt("key_height_dp", 48)
        set(value) = prefs.edit().putInt("key_height_dp", value).apply()

    var keyBorderStrokeDp: Int
        get() = prefs.getInt("key_border_dp", 1)
        set(value) = prefs.edit().putInt("key_border_dp", value).apply()

    var showNumberRow: Boolean
        get() = prefs.getBoolean("show_number_row", true)
        set(value) = prefs.edit().putBoolean("show_number_row", value).apply()

    var showCustomMacroRow: Boolean
        get() = prefs.getBoolean("show_macro_row", true)
        set(value) = prefs.edit().putBoolean("show_macro_row", value).apply()

    var customMacrosCsv: String
        get() = prefs.getString("custom_macros", "Copy,Paste,SelectAll,◀,▶,¯\\_(ツ)_/¯") ?: "Copy,Paste,SelectAll,◀,▶,¯\\_(ツ)_/¯"
        set(value) = prefs.edit().putString("custom_macros", value).apply()

    fun getActiveTheme(): ThemeColors {
        return when (themePreset) {
            "cyber_neon" -> ThemeColors(
                "Cyber Neon AMOLED",
                Color.parseColor("#05050A"),
                Color.parseColor("#121324"),
                Color.parseColor("#1D1E38"),
                Color.parseColor("#00F0FF"),
                Color.parseColor("#E8FFFF"),
                Color.parseColor("#00F0FF")
            )
            "catppuccin" -> ThemeColors(
                "Catppuccin Mocha",
                Color.parseColor("#1E1E2E"),
                Color.parseColor("#313244"),
                Color.parseColor("#45475A"),
                Color.parseColor("#CBA6F7"),
                Color.parseColor("#CDD6F4"),
                Color.parseColor("#585B70")
            )
            "sakura" -> ThemeColors(
                "Sakura Pink",
                Color.parseColor("#231924"),
                Color.parseColor("#38273B"),
                Color.parseColor("#4E3552"),
                Color.parseColor("#FF85B3"),
                Color.parseColor("#FFEBF3"),
                Color.parseColor("#FF85B3")
            )
            "amoled_stealth" -> ThemeColors(
                "AMOLED Stealth",
                Color.parseColor("#000000"),
                Color.parseColor("#141414"),
                Color.parseColor("#1F1F1F"),
                Color.parseColor("#4CAF50"),
                Color.parseColor("#FFFFFF"),
                Color.parseColor("#2C2C2C")
            )
            else -> ThemeColors(
                "Gboard Material Dark",
                Color.parseColor("#1B1B1F"),
                Color.parseColor("#303036"),
                Color.parseColor("#242429"),
                Color.parseColor("#A8C7FA"),
                Color.parseColor("#E3E3E8"),
                Color.parseColor("#44464F")
            )
        }
    }
}
