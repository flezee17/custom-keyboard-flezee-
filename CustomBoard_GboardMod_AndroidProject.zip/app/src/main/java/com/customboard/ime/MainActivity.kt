package com.customboard.ime

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: KeyboardPreferences
    private lateinit var soundEngine: SoundEngine
    private lateinit var previewKeyboard: KeyboardLayoutView
    private lateinit var testInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = KeyboardPreferences(this)
        soundEngine = SoundEngine(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#111217"))
        }

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 48)
        }

        val title = TextView(this).apply {
            text = "CustomBoard Studio"
            textSize = 24f
            setTextColor(Color.WHITE)
        }
        val subtitle = TextView(this).apply {
            text = "Кастомная клавиатура в стиле Gboard: свитч-звуки, темы и макро-кнопки"
            textSize = 13f
            setTextColor(Color.parseColor("#9AA0A6"))
            setPadding(0, 6, 0, 28)
        }
        content.addView(title)
        content.addView(subtitle)

        // Enable / Select IME Buttons
        val rowButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val btnEnable = Button(this).apply {
            text = "1. Включить в настройках"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }
        val btnSelect = Button(this).apply {
            text = "2. Выбрать клавиатуру"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        rowButtons.addView(btnEnable, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        rowButtons.addView(btnSelect, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(rowButtons)

        // Sound Profile Selector
        content.addView(sectionHeader("Звук тайпинга (Механические свитчи)"))
        val sounds = listOf(
            "thock" to "Creamy Thock (Глубокий кремовый)",
            "blue" to "Cherry MX Blue (Кликающий)",
            "red" to "Linear Red (Тихий линейный)",
            "bubble" to "Bubble Pop (Пузырьковый)",
            "typewriter" to "Retro Typewriter (Печатная машинка)",
            "none" to "Без звука"
        )
        val soundSpinner = Spinner(this)
        soundSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sounds.map { it.second })
        soundSpinner.setSelection(sounds.indexOfFirst { it.first == prefs.soundProfile }.coerceAtLeast(0))
        soundSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, pos: Int, id: Long) {
                prefs.soundProfile = sounds[pos].first
                soundEngine.playKeySound(prefs.soundProfile, prefs.soundVolume)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        content.addView(soundSpinner)

        // Theme Preset Selector
        content.addView(sectionHeader("Тема оформления"))
        val themes = listOf(
            "gboard_dark" to "Gboard Material Dark",
            "cyber_neon" to "Cyber Neon AMOLED",
            "catppuccin" to "Catppuccin Mocha",
            "sakura" to "Sakura Pink",
            "amoled_stealth" to "AMOLED Stealth"
        )
        val themeSpinner = Spinner(this)
        themeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, themes.map { it.second })
        themeSpinner.setSelection(themes.indexOfFirst { it.first == prefs.themePreset }.coerceAtLeast(0))
        themeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, pos: Int, id: Long) {
                prefs.themePreset = themes[pos].first
                previewKeyboard.rebuildKeyboard()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        content.addView(themeSpinner)

        // Sliders
        content.addView(sectionHeader("Скругление кнопок (dp): ${prefs.keyCornerRadiusDp}"))
        val radiusSeek = SeekBar(this).apply {
            max = 24
            progress = prefs.keyCornerRadiusDp
            setOnSeekBarChangeListener(simpleSeek {
                prefs.keyCornerRadiusDp = it
                previewKeyboard.rebuildKeyboard()
            })
        }
        content.addView(radiusSeek)

        content.addView(sectionHeader("Обводка кнопок (dp): ${prefs.keyBorderStrokeDp}"))
        val borderSeek = SeekBar(this).apply {
            max = 4
            progress = prefs.keyBorderStrokeDp
            setOnSeekBarChangeListener(simpleSeek {
                prefs.keyBorderStrokeDp = it
                previewKeyboard.rebuildKeyboard()
            })
        }
        content.addView(borderSeek)

        // Custom Macro Buttons Input
        content.addView(sectionHeader("Кастомный верхний ряд кнопок (через запятую)"))
        val macroEdit = EditText(this).apply {
            setText(prefs.customMacrosCsv)
            setTextColor(Color.WHITE)
        }
        val btnSaveMacros = Button(this).apply {
            text = "Обновить кастомные кнопки"
            setOnClickListener {
                prefs.customMacrosCsv = macroEdit.text.toString()
                previewKeyboard.rebuildKeyboard()
            }
        }
        content.addView(macroEdit)
        content.addView(btnSaveMacros)

        // Test field
        content.addView(sectionHeader("Тестовое поле ввода"))
        testInput = EditText(this).apply {
            hint = "Нажимай на кнопки превью внизу..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
        }
        content.addView(testInput)

        scroll.addView(content)
        root.addView(scroll)

        // Live Interactive Keyboard Preview at Bottom
        previewKeyboard = KeyboardLayoutView(this, prefs, object : KeyboardLayoutView.Listener {
            override fun onTextInput(text: String) {
                testInput.append(text)
            }
            override fun onBackspace() {
                val len = testInput.text.length
                if (len > 0) testInput.text.delete(len - 1, len)
            }
            override fun onEnter() {
                testInput.append("\n")
            }
            override fun onCursorMove(delta: Int) {}
            override fun onMacroAction(action: String) {
                testInput.append("[$action]")
            }
            override fun onKeyPressFeedback(isSpecial: Boolean) {
                soundEngine.playKeySound(prefs.soundProfile, prefs.soundVolume, isSpecial)
            }
        })
        root.addView(previewKeyboard)

        setContentView(root)
    }

    private fun sectionHeader(title: String): TextView {
        return TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.parseColor("#A8C7FA"))
            setPadding(0, 24, 0, 8)
        }
    }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    override fun onDestroy() {
        soundEngine.release()
        super.onDestroy()
    }
}
